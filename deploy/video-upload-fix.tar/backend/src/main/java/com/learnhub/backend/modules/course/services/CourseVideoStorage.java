package com.learnhub.backend.modules.course.services;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.learnhub.backend.modules.course.dtos.VideoInitRequest;
import com.learnhub.backend.modules.course.dtos.VideoReadyDTO;
import com.learnhub.backend.modules.course.dtos.VideoSessionDTO;
import com.learnhub.backend.modules.course.support.Mp4Duration;
import com.learnhub.backend.modules.user.exceptions.AuthException;

import jakarta.annotation.PreDestroy;

@Service
public class CourseVideoStorage {
    private static final Set<String> ALLOWED = Set.of(
            "video/mp4",
            "video/webm",
            "video/quicktime",
            "video/x-matroska",
            "video/x-msvideo");
    private static final long SESSION_TTL_SECONDS = 6 * 60 * 60;

    private final int chunkSize;
    private final long maxSize;
    private final String ffmpeg;
    private final String ffprobe;
    private final List<VideoNode> nodes;
    private final Path tempRoot;
    private final Map<String, UploadSession> sessions = new ConcurrentHashMap<>();
    private final ExecutorService encoder = Executors.newSingleThreadExecutor(thread -> {
        Thread worker = new Thread(thread, "learnhub-video-encode");
        worker.setDaemon(true);
        return worker;
    });
    private volatile Boolean ffmpegReady;
    private volatile Boolean ffprobeReady;

    public CourseVideoStorage(
            @Value("${learnhub.video.chunk-size-bytes:8388608}") int chunkSize,
            @Value("${learnhub.video.max-size-bytes:536870912}") long maxSize,
            @Value("${learnhub.video.ffmpeg:ffmpeg}") String ffmpeg,
            @Value("${learnhub.video.ffprobe:ffprobe}") String ffprobe,
            @Value("${learnhub.video.nodes:}") String nodeConfig) {
        this.chunkSize = chunkSize;
        this.maxSize = maxSize;
        this.ffmpeg = ffmpeg;
        this.ffprobe = ffprobe;
        this.nodes = resolveNodes(nodeConfig);
        Path first = this.nodes.get(0).root;
        Path tmpParent = first.getParent() == null ? first : first.getParent();
        this.tempRoot = tmpParent.resolve("tmp").toAbsolutePath().normalize();
        for (VideoNode node : nodes) {
            try {
                Files.createDirectories(node.root);
            } catch (IOException ignored) {
            }
        }
        try {
            Files.createDirectories(tempRoot);
        } catch (IOException ignored) {
        }
    }

    @PreDestroy
    public void shutdown() {
        encoder.shutdownNow();
    }

    public VideoSessionDTO init(VideoInitRequest request) {
        if (request == null || request.getSize() == null || request.getSize() <= 0) {
            throw new AuthException(HttpStatus.BAD_REQUEST, "Dung lượng video không hợp lệ", "video");
        }
        if (request.getSize() > maxSize) {
            throw new AuthException(HttpStatus.BAD_REQUEST, "Video tối đa 512MB", "video");
        }
        String contentType = request.getContentType() == null ? "" : request.getContentType().toLowerCase();
        if (!ALLOWED.contains(contentType) && !looksLikeVideo(request.getFilename())) {
            throw new AuthException(HttpStatus.BAD_REQUEST, "Video phải là MP4, WEBM, MOV hoặc MKV", "video");
        }
        int total = request.getTotalChunks() == null || request.getTotalChunks() < 1
                ? (int) Math.ceil(request.getSize() / (double) chunkSize)
                : request.getTotalChunks();
        VideoNode node = pickNode();
        String sessionId = UUID.randomUUID().toString();
        Path work = tempRoot.resolve(sessionId);
        try {
            Files.createDirectories(work);
        } catch (IOException ignored) {
            throw new AuthException(HttpStatus.INTERNAL_SERVER_ERROR, "Không thể tạo phiên tải video");
        }
        UploadSession session = new UploadSession(node.name, total, Instant.now(), work);
        writeMeta(session);
        sessions.put(sessionId, session);
        return new VideoSessionDTO(sessionId, chunkSize, node.name, total);
    }

    public void saveChunk(String sessionId, int index, MultipartFile chunk) {
        UploadSession session = requireSession(sessionId);
        if (index < 0 || index >= session.totalChunks) {
            throw new AuthException(HttpStatus.BAD_REQUEST, "Mảnh video không hợp lệ", "video");
        }
        if (chunk == null || chunk.isEmpty()) {
            throw new AuthException(HttpStatus.BAD_REQUEST, "Mảnh video trống", "video");
        }
        if (chunk.getSize() > chunkSize + 1024) {
            throw new AuthException(HttpStatus.BAD_REQUEST, "Mảnh video vượt kích thước cho phép", "video");
        }
        Path part = session.work.resolve(String.format("%05d.part", index));
        try (InputStream in = chunk.getInputStream()) {
            Files.copy(in, part, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ignored) {
            throw new AuthException(HttpStatus.INTERNAL_SERVER_ERROR, "Không thể lưu mảnh video");
        }
    }

    public VideoReadyDTO complete(String sessionId) {
        return startComplete(sessionId);
    }

    public VideoReadyDTO startComplete(String sessionId) {
        UploadSession session = requireSession(sessionId);
        synchronized (session.lock) {
            if ("READY".equals(session.phase) && session.ready != null) {
                return session.ready;
            }
            if ("PROCESSING".equals(session.phase)) {
                return waitBriefly(session);
            }
            session.phase = "PROCESSING";
            session.error = null;
        }
        encoder.execute(() -> process(session));
        return waitBriefly(session);
    }

    public VideoReadyDTO status(String sessionId) {
        UploadSession session = requireSession(sessionId);
        synchronized (session.lock) {
            if ("READY".equals(session.phase) && session.ready != null) {
                return session.ready;
            }
            if ("FAILED".equals(session.phase)) {
                return VideoReadyDTO.failed(session.error == null ? "Không thể xử lý video" : session.error);
            }
            return VideoReadyDTO.processing();
        }
    }

    public void abort(String sessionId) {
        UploadSession session = sessions.remove(sessionId);
        if (session != null) {
            cleanup(session);
        }
    }

    public void deleteIfOwned(String videoUrl) {
        Path file = resolvePublished(videoUrl);
        if (file == null) {
            return;
        }
        try {
            Files.deleteIfExists(file);
        } catch (IOException ignored) {
        }
    }

    public Path resolvePublished(String videoUrl) {
        if (videoUrl == null || !videoUrl.startsWith("/api/media/videos/")) {
            return null;
        }
        String rest = videoUrl.substring("/api/media/videos/".length());
        int slash = rest.indexOf('/');
        if (slash <= 0) {
            return null;
        }
        return resolvePublished(rest.substring(0, slash), rest.substring(slash + 1));
    }

    public Path resolvePublished(String nodeName, String filename) {
        if (nodeName == null || filename == null) {
            return null;
        }
        if (filename.contains("..") || filename.contains("/") || filename.contains("\\")) {
            return null;
        }
        VideoNode node;
        try {
            node = nodeByName(nodeName);
        } catch (AuthException ignored) {
            return null;
        }
        Path file = node.root.resolve(filename).normalize();
        if (!file.startsWith(node.root) || !Files.isRegularFile(file)) {
            return null;
        }
        return file;
    }

    public int durationOf(String videoUrl) {
        Path file = resolvePublished(videoUrl);
        if (file == null) {
            return 0;
        }
        return probeDuration(file);
    }

    private VideoReadyDTO waitBriefly(UploadSession session) {
        long deadline = System.currentTimeMillis() + 8000;
        while (System.currentTimeMillis() < deadline) {
            synchronized (session.lock) {
                if ("READY".equals(session.phase) && session.ready != null) {
                    return session.ready;
                }
                if ("FAILED".equals(session.phase)) {
                    return VideoReadyDTO.failed(session.error == null ? "Không thể xử lý video" : session.error);
                }
            }
            try {
                Thread.sleep(200);
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        return VideoReadyDTO.processing();
    }

    private void process(UploadSession session) {
        try {
            VideoReadyDTO ready = finish(session);
            synchronized (session.lock) {
                session.ready = ready;
                session.phase = "READY";
            }
        } catch (AuthException exception) {
            synchronized (session.lock) {
                session.phase = "FAILED";
                session.error = exception.getMessage();
            }
        } catch (Exception ignored) {
            synchronized (session.lock) {
                session.phase = "FAILED";
                session.error = "Không thể ghép video";
            }
        }
    }

    private VideoReadyDTO finish(UploadSession session) throws IOException {
        Path assembled = session.work.resolve("source.bin");
        assemble(session, assembled);
        VideoNode node = nodeByName(session.node);
        String filename = UUID.randomUUID() + ".mp4";
        Path output = node.root.resolve(filename);
        transcode(assembled, output);
        int duration = probeDuration(output);
        long bytes = Files.size(output);
        cleanup(session);
        return new VideoReadyDTO("/api/media/videos/" + node.name + "/" + filename, duration, bytes, node.name);
    }

    private void assemble(UploadSession session, Path assembled) throws IOException {
        try (OutputStream out = Files.newOutputStream(assembled, StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING)) {
            for (int index = 0; index < session.totalChunks; index++) {
                Path part = session.work.resolve(String.format("%05d.part", index));
                if (!Files.isRegularFile(part)) {
                    throw new AuthException(HttpStatus.BAD_REQUEST, "Thiếu mảnh video " + (index + 1), "video");
                }
                Files.copy(part, out);
            }
        }
        if (Files.size(assembled) > maxSize) {
            throw new AuthException(HttpStatus.BAD_REQUEST, "Video tối đa 512MB", "video");
        }
    }

    private void transcode(Path input, Path output) {
        if (hasFfmpeg() && isH264(input) && remux(input, output)) {
            return;
        }
        if (hasFfmpeg() && encode(input, output)) {
            return;
        }
        try {
            Files.copy(input, output, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ignored) {
            throw new AuthException(HttpStatus.INTERNAL_SERVER_ERROR, "Không thể lưu video");
        }
    }

    private boolean remux(Path input, Path output) {
        return run(List.of(
                ffmpeg,
                "-y",
                "-i",
                input.toAbsolutePath().toString(),
                "-c",
                "copy",
                "-movflags",
                "+faststart",
                output.toAbsolutePath().toString()), 120);
    }

    private boolean encode(Path input, Path output) {
        return run(List.of(
                ffmpeg,
                "-y",
                "-i",
                input.toAbsolutePath().toString(),
                "-map",
                "0:v:0",
                "-map",
                "0:a?",
                "-c:v",
                "libx264",
                "-preset",
                "ultrafast",
                "-threads",
                "2",
                "-crf",
                "28",
                "-maxrate",
                "1800k",
                "-bufsize",
                "3600k",
                "-vf",
                "scale=w='min(1280,iw)':h='min(720,ih)':force_original_aspect_ratio=decrease:force_divisible_by=2",
                "-c:a",
                "aac",
                "-b:a",
                "96k",
                "-ac",
                "2",
                "-movflags",
                "+faststart",
                output.toAbsolutePath().toString()), 15 * 60);
    }

    private boolean isH264(Path input) {
        String codec = videoCodec(input);
        return "h264".equals(codec) || "avc1".equals(codec);
    }

    private String videoCodec(Path input) {
        if (!hasFfprobe()) {
            return "";
        }
        List<String> command = List.of(
                ffprobe,
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=codec_name",
                "-of",
                "default=nw=1:nk=1",
                input.toAbsolutePath().toString());
        try {
            Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
            String raw = new String(process.getInputStream().readAllBytes()).trim().toLowerCase();
            if (!process.waitFor(20, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return "";
            }
            return raw;
        } catch (IOException | InterruptedException ignored) {
            return "";
        }
    }

    private int probeDuration(Path file) {
        int parsed = Mp4Duration.seconds(file);
        if (parsed > 0 || !hasFfprobe()) {
            return parsed;
        }
        List<String> command = List.of(
                ffprobe,
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "csv=p=0",
                file.toAbsolutePath().toString());
        try {
            Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
            String raw = new String(process.getInputStream().readAllBytes()).trim();
            if (!process.waitFor(30, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return 0;
            }
            if (raw.isBlank()) {
                return 0;
            }
            return (int) Math.round(Double.parseDouble(raw));
        } catch (IOException | InterruptedException | NumberFormatException ignored) {
            return 0;
        }
    }

    private boolean run(List<String> command, int timeoutSeconds) {
        try {
            Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
            process.getInputStream().transferTo(OutputStream.nullOutputStream());
            if (!process.waitFor(timeoutSeconds, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return false;
            }
            return process.exitValue() == 0;
        } catch (IOException | InterruptedException ignored) {
            return false;
        }
    }

    private boolean hasFfmpeg() {
        if (ffmpegReady == null) {
            ffmpegReady = hasBinary(ffmpeg);
        }
        return Boolean.TRUE.equals(ffmpegReady);
    }

    private boolean hasFfprobe() {
        if (ffprobeReady == null) {
            ffprobeReady = hasBinary(ffprobe);
        }
        return Boolean.TRUE.equals(ffprobeReady);
    }

    private boolean hasBinary(String binary) {
        try {
            Process process = new ProcessBuilder(binary, "-version").redirectErrorStream(true).start();
            process.getInputStream().transferTo(OutputStream.nullOutputStream());
            return process.waitFor(8, TimeUnit.SECONDS) && process.exitValue() == 0;
        } catch (IOException | InterruptedException ignored) {
            return false;
        }
    }

    private UploadSession requireSession(String sessionId) {
        purgeExpired();
        UploadSession session = sessions.get(sessionId);
        if (session != null) {
            return session;
        }
        UploadSession loaded = loadFromDisk(sessionId);
        if (loaded == null) {
            throw new AuthException(HttpStatus.NOT_FOUND, "Phiên tải video đã hết hạn");
        }
        UploadSession existing = sessions.putIfAbsent(sessionId, loaded);
        return existing == null ? loaded : existing;
    }

    private UploadSession loadFromDisk(String sessionId) {
        if (sessionId == null || sessionId.contains("..") || sessionId.contains("/") || sessionId.contains("\\")) {
            return null;
        }
        Path work = tempRoot.resolve(sessionId).normalize();
        if (!work.startsWith(tempRoot) || !Files.isDirectory(work)) {
            return null;
        }
        String node = nodes.get(0).name;
        int total = 0;
        Instant created = Instant.now();
        Path meta = work.resolve("meta.txt");
        if (Files.isRegularFile(meta)) {
            try {
                List<String> lines = Files.readAllLines(meta);
                if (lines.size() >= 3) {
                    node = lines.get(0).trim();
                    total = Integer.parseInt(lines.get(1).trim());
                    created = Instant.ofEpochSecond(Long.parseLong(lines.get(2).trim()));
                }
            } catch (IOException | NumberFormatException ignored) {
            }
        }
        if (total < 1) {
            total = countParts(work);
        }
        if (total < 1) {
            return null;
        }
        return new UploadSession(node, total, created, work);
    }

    private int countParts(Path work) {
        int count = 0;
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(work, "*.part")) {
            for (Path ignored : stream) {
                count += 1;
            }
        } catch (IOException ignored) {
            return 0;
        }
        return count;
    }

    private void writeMeta(UploadSession session) {
        try {
            Files.writeString(
                    session.work.resolve("meta.txt"),
                    session.node + "\n" + session.totalChunks + "\n" + session.createdAt.getEpochSecond() + "\n");
        } catch (IOException ignored) {
        }
    }

    private void purgeExpired() {
        Instant limit = Instant.now().minusSeconds(SESSION_TTL_SECONDS);
        sessions.entrySet().removeIf(entry -> {
            if (entry.getValue().createdAt.isBefore(limit)) {
                cleanup(entry.getValue());
                return true;
            }
            return false;
        });
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(tempRoot)) {
            for (Path dir : stream) {
                if (!Files.isDirectory(dir)) {
                    continue;
                }
                String id = dir.getFileName().toString();
                if (sessions.containsKey(id)) {
                    continue;
                }
                UploadSession loaded = loadFromDisk(id);
                if (loaded != null && loaded.createdAt.isBefore(limit)) {
                    cleanup(loaded);
                }
            }
        } catch (IOException ignored) {
        }
    }

    private void cleanup(UploadSession session) {
        if (session == null || session.work == null) {
            return;
        }
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(session.work)) {
            for (Path path : stream) {
                Files.deleteIfExists(path);
            }
        } catch (IOException ignored) {
        }
        try {
            Files.deleteIfExists(session.work);
        } catch (IOException ignored) {
        }
    }

    private VideoNode pickNode() {
        return nodes.stream()
                .min(Comparator.comparingLong(this::usedBytes))
                .orElse(nodes.get(0));
    }

    private long usedBytes(VideoNode node) {
        try (var walk = Files.walk(node.root)) {
            return walk
                    .filter(Files::isRegularFile)
                    .mapToLong(path -> {
                        try {
                            return Files.size(path);
                        } catch (IOException ignored) {
                            return 0L;
                        }
                    })
                    .sum();
        } catch (IOException ignored) {
            return Long.MAX_VALUE;
        }
    }

    private VideoNode nodeByName(String name) {
        return nodes.stream()
                .filter(node -> node.name.equals(name))
                .findFirst()
                .orElseThrow(() -> new AuthException(HttpStatus.BAD_REQUEST, "Node video không hợp lệ"));
    }

    private List<VideoNode> resolveNodes(String config) {
        List<VideoNode> resolved = new ArrayList<>();
        if (config != null && !config.isBlank()) {
            String[] parts = config.split(",");
            int index = 0;
            for (String part : parts) {
                String trimmed = part.trim();
                if (trimmed.isEmpty()) {
                    continue;
                }
                Path path = Paths.get(trimmed).toAbsolutePath().normalize();
                if (!usableRoot(path)) {
                    continue;
                }
                resolved.add(new VideoNode("n" + index, path));
                index += 1;
            }
        }
        boolean windows = System.getProperty("os.name", "").toLowerCase().contains("win");
        if (resolved.isEmpty() && !windows) {
            Path linux = Paths.get("/var/learnhub-videos/n0");
            if (usableRoot(linux)) {
                resolved.add(new VideoNode("n0", linux.toAbsolutePath().normalize()));
            }
        }
        if (resolved.isEmpty() && windows) {
            Path drive = Paths.get("C:\\learnhub-videos\\n0");
            if (usableRoot(drive)) {
                resolved.add(new VideoNode("n0", drive.toAbsolutePath().normalize()));
            }
        }
        if (resolved.isEmpty()) {
            Path fallback = Paths.get("uploads", "videos", "n0").toAbsolutePath().normalize();
            try {
                Files.createDirectories(fallback);
            } catch (IOException ignored) {
            }
            resolved.add(new VideoNode("n0", fallback));
        }
        return List.copyOf(resolved);
    }

    private boolean usableRoot(Path root) {
        Path drive = root.getRoot();
        if (drive != null && !Files.exists(drive)) {
            return false;
        }
        try {
            Files.createDirectories(root);
            return Files.isWritable(root);
        } catch (IOException ignored) {
            return false;
        }
    }

    private boolean looksLikeVideo(String filename) {
        if (filename == null) {
            return false;
        }
        String lower = filename.toLowerCase();
        return lower.endsWith(".mp4")
                || lower.endsWith(".webm")
                || lower.endsWith(".mov")
                || lower.endsWith(".mkv")
                || lower.endsWith(".avi");
    }

    private record VideoNode(String name, Path root) {
    }

    private static final class UploadSession {
        private final String node;
        private final int totalChunks;
        private final Instant createdAt;
        private final Path work;
        private final Object lock = new Object();
        private String phase = "UPLOADING";
        private VideoReadyDTO ready;
        private String error;

        private UploadSession(String node, int totalChunks, Instant createdAt, Path work) {
            this.node = node;
            this.totalChunks = totalChunks;
            this.createdAt = createdAt;
            this.work = work;
        }
    }
}
